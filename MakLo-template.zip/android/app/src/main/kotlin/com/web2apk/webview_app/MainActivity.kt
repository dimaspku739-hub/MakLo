package com.web2apk.webview_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
