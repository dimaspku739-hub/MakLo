# MakLo — Flutter WebView Builder Template

Template dasar project Flutter WebView untuk repo builder bot **Web2Apk FLUX-X**.

## Cara pakai

1. Extract isi ZIP ini.
2. Upload **semua isi folder** (termasuk folder tersembunyi `.github` dan `.gitignore`) ke branch `main` repo GitHub `MakLo`, menimpa `README.md` bawaan.
3. Pastikan struktur akhir di repo seperti ini:
   ```
   MakLo/
   ├── .github/workflows/build.yml
   ├── android/...
   ├── lib/main.dart
   ├── pubspec.yaml
   └── .gitignore
   ```
4. Di `setting.js` bot Telegram, isi:
   ```js
   GITHUB_USERNAME: "dimaspku739-hub",
   BUILDER_REPO: "MakLo",
   ```
5. Restart bot.

## Catatan penting

- File `lib/main.dart` di sini hanya **template dasar** — saat bot memproses build dari URL,
  bot akan membuat ulang `lib/main.dart` dengan URL yang dikirim user, lalu push ke branch baru
  `build-<jobId>-release` atau `build-<jobId>-debug`. Jadi isi `main.dart` di branch `main` ini
  tidak perlu diubah manual, cukup sebagai referensi/basis.
- `android/app/build.gradle` sudah diset agar APK release ditandatangani pakai **debug signing key**
  supaya bot bisa langsung build APK tanpa perlu setup keystore release. Cukup untuk kebutuhan
  build cepat/testing. Kalau nanti butuh APK yang bisa di-publish ke Play Store, keystore release
  perlu disiapkan terpisah.
- Versi yang dipakai:
  - Flutter: 3.24.0 (stable) — diatur di `build.yml`
  - `webview_flutter`: ^4.7.0 — di `pubspec.yaml`
  - Kotlin: 1.9.10, Android Gradle Plugin: 8.1.2, compileSdk/targetSdk: 34, minSdk: 21

## Artifact

Workflow `.github/workflows/build.yml` akan otomatis:
- Trigger di setiap push branch (kecuali branch `gh-pages-*` yang dipakai fitur Deploy Web).
- Build APK release/debug sesuai akhiran nama branch.
- Upload hasil APK sebagai artifact bernama **`release-apk`** (nama ini wajib persis,
  karena bot Telegram mencarinya dengan nama itu).
